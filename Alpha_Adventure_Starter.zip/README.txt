Alpha Adventure - starter web app
1. Open index.html in a browser.
2. Demo OTP is 123456.
3. Real SMS verification needs Firebase Authentication or another OTP backend.
4. Background audio is not included because browsers require a user gesture and real music should be licensed; child-friendly sound can be added later.
5. This starter can be wrapped into an Android APK after the web app is finalized.
