ALPHA ADVENTURE v2
- Logo included: logo.svg
- English: 10 questions
- Math: 10 questions
- Hindi: 10 questions
- Pass mark: 7/10
- Demo mobile OTP: 123456
- Child-friendly generated background music/sounds using Web Audio (no external copyrighted song).
- Real SMS OTP requires Firebase Authentication or a secure backend.
- To run: open index.html in a browser, or upload index.html + logo.svg directly to GitHub Pages.
